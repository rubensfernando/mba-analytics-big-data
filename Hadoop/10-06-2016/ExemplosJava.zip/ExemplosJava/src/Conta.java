
public class Conta {
	
	public int numero;
	public String nomeCliente;
	public double saldo;
	public double limite;
	
	public void sacarDinheiro(double quantidade){
		double novoSaldo = this.saldo - quantidade;
		this.saldo = novoSaldo;
	}
	
	public void depositarDinheiro(double quantidade){
		this.saldo = this.saldo + quantidade;
	}

}






