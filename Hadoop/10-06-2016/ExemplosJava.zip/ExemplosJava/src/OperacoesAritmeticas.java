public class OperacoesAritmeticas {
	
		
	public static void main(String[] args){
		int valorA = 10;
		int valorB = 5;
		int valorC = 15;
		
		String nome = "Maria";
		
		int valorTotal = valorA + valorB + valorC;
		
		System.out.println("Nome = " + nome);
		System.out.println("Valor do produto A = " + valorA);
		System.out.println("Valor total = " + valorTotal);
	}
	
}
