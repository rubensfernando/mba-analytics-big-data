public class ComandosDeSelecao {
	
	public static void main(String[] args){
		double score = 60;
		
		if(score >= 90){
			System.out.println("Credito aprovado");
		} else if(score >= 70){
			System.out.println("Credito deve ser avaliado");
		}else{
			System.out.println("Credito negado");
		}
	}

}
