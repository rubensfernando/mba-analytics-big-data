
public class Banco {
	
	public static void main(String[] args){
		Conta contaX;
		contaX = new Conta();
		
		contaX.nomeCliente = "Maria da Silva";
		contaX.saldo = 100;
		
		contaX.sacarDinheiro(50);
		contaX.depositarDinheiro(200);
		
		System.out.println(contaX.saldo);
	}

}



