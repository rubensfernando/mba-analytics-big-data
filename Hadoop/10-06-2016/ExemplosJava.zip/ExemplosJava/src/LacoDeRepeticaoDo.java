
public class LacoDeRepeticaoDo {
	
	public static void main(String[] args){
		
		//laço Do
		int contador = 0;
		int soma = 0;
		while(contador < 10){
			soma = soma + contador;
			System.out.println("Valor do contador = " + contador + " Valor da soma = " + soma);			
			contador++;
		}
	}

}
