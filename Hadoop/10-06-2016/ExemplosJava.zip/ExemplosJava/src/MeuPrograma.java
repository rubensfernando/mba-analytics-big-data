public class MeuPrograma {
	
	/*
	 * comentario da classe MeuPrograma
	 */
	public static void main(String[] args){
		System.out.println("Meu primeiro programa"); //exemplo de comentario de uma linha
	}

}









