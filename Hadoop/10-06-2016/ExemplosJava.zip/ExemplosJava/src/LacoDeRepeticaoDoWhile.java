
public class LacoDeRepeticaoDoWhile {

	public static void main(String[] args){
		
		//laço Do-while
		int contador = 0;
		int soma = 0;
		do{
			soma = soma + contador;
			System.out.println("Valor do contador = " + contador + " Valor da soma = " + soma);			
			contador++;	
		}while(contador < 10);
	}
}

