public class LacoDeRepeticaoFor {
	
	
	public static void main(String[] args){
		
		//laço For
		int soma = 0;
		for(int contador = 0; contador <10; contador++){
			soma = soma + contador;
			System.out.println("Valor do contador = " + contador + " Valor da soma = " + soma);
			
		}
		
	}

}
