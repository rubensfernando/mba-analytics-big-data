import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class ContaPalavrasDriver {

	public static void main(String[] args) throws Exception {
		// Cria um objeto chamado conf do tipo configuration
		Configuration conf = new Configuration();
		// cria um objeto do tipo Job chamado job; o primeiro parametro do
		// metodo e o objeto de configuracao e o segundo e para nomear o job
		// durante a execucao
		Job job = Job.getInstance(conf, "contapalavrasdriver");
		// especificar para o job qual classe vai utilzar para executar
		job.setJarByClass(ContaPalavrasDriver.class);
		// Indica a classe do mapper do projeto atual que sera utilizada
		job.setMapperClass(ContaPalavrasMap.class);
		// Indica a classe do Reducer do projeto atual que sera utilizada
		job.setReducerClass(ContaPalavrasReduce.class);
		// É precisso indicar qual tipo de dados sera utilizado entre as
		// interacoes map e reduce
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		//Configua a pasta de dados iniciais; a primeira posicao do comando sera o diretorio de entrada
		FileInputFormat.addInputPath(job, new Path(args[0]));
		//Configuracao a pasta de saida; 
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		//Aqui ele comeca a executar os processos definidos anteriormente
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
